﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class StringUtil
    {
        private readonly static string[] dbIntTypes = { "TINYINT","SMALLINT","INTEGER","NUMBER"};
        private readonly static string[] dbDateTypes = { "DATE", "TIMESTAMP" };
        //ABCD_EFG => abcdEfg
        public static string convertUnderScoreToCamelCase(string value)
        {
            var camelCase = value.Split(new[] { "_" }, StringSplitOptions.RemoveEmptyEntries)
                .Select((s, i) => (i == 0) ? s.Substring(0, 1).ToLower() + s.Substring(1).ToLower() : s.Substring(0, 1).ToUpper() + s.Substring(1).ToLower());

            return string.Concat(camelCase);
        }

        public static string convertEntityJavaType(string value)
        {
            if (dbIntTypes.Contains(value))
            {
                return "int";
            }else if(dbDateTypes.Contains(value))
            {
                return "Timestamp";
            }


            return "String";
        }

        public static string convertSqlColumnType(string value)
        {
            if (dbIntTypes.Contains(value))
            {
                return "Integer";
            }else if(dbDateTypes.Contains(value))
            {
                return "Timestamp";
            }

            return "String";
        }

        public static string convertJdbcType(string value)
        {
            if (dbIntTypes.Contains(value))
            {
                return "JDBCType.INTEGER";
            }else if(dbDateTypes.Contains(value))
            {
                return "JDBCTYPE.TIMESTAMP";
            }

            return "JDBCType.VARCHAR";
        }
    }
}
