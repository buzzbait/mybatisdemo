﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class CommonConstants
    {
        public static readonly string APP_TITLE = "SysoneModel";        

    }
}
