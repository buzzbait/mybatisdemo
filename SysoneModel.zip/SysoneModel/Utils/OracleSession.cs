﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class OracleSession
    {
        private static OracleConnection oraCon = null;

        public static string connectServer(string connectionString)
        {
            try
            {
                closeServer();
                oraCon = new OracleConnection(connectionString);
                oraCon.Open();
                return null;
            }catch(Exception ex)
            {                
                return ex.Message;
            }            
        }

        public static void closeServer()
        {
            if (oraCon == null) return;
            oraCon.Close();
            oraCon.Dispose();
        }

        public static OracleConnection getConnection()
        {
            return oraCon;
        }
    }
}
