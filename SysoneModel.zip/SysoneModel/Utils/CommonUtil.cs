﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SysoneModel.Utils
{
    class CommonUtil
    {
        public static void setDataGridView(System.Windows.Forms.DataGridView sender)
        {
            sender.AutoGenerateColumns = false;
            sender.AllowDrop = false;
            sender.AllowUserToAddRows = false;
            sender.AllowUserToDeleteRows = false;
            sender.AllowUserToOrderColumns = false;
            sender.AllowUserToResizeRows = false;
            sender.RowHeadersVisible = true;
            sender.RowHeadersWidth = 24;
            sender.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            sender.ReadOnly = true;
        }

        
    }
}
