﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SysoneModel.Utils
{
    class MakerEditor
    {
        private static string keywords = @"public|class|private|package|import|final|static|new|extends|interface|Optional";
        private static string lombokKeywords = "@Getter|@Setter|@Builder";

        public static void changeColor(RichTextBox editor )
        {
            MatchCollection keywordMatches = Regex.Matches(editor.Text, keywords);
            MatchCollection lombokKeywordMatches = Regex.Matches(editor.Text, lombokKeywords);

            foreach (Match m in keywordMatches)
            {
                editor.SelectionStart = m.Index;
                editor.SelectionLength = m.Length;
                editor.SelectionColor = System.Drawing.Color.Purple;
                editor.SelectionFont = new System.Drawing.Font(editor.Font.FontFamily, 10, System.Drawing.FontStyle.Bold);
            }
            
            foreach (Match m in lombokKeywordMatches)
            {
                editor.SelectionStart = m.Index;
                editor.SelectionLength = m.Length;
                editor.SelectionColor = System.Drawing.Color.Green;
                editor.SelectionFont = new System.Drawing.Font(editor.Font.FontFamily, 10, System.Drawing.FontStyle.Bold);
            }
        }
    }
}
