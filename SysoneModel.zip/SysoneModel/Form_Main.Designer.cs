﻿namespace SysoneModel
{
    partial class Form_Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Top = new System.Windows.Forms.Panel();
            this.btn_MakeModel = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.pic_Online = new System.Windows.Forms.PictureBox();
            this.pic_Off = new System.Windows.Forms.PictureBox();
            this.btn_Connect = new System.Windows.Forms.Button();
            this.statusStrip_Main = new System.Windows.Forms.StatusStrip();
            this.status_Connect = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel_Left = new System.Windows.Forms.Panel();
            this.dgv_Table = new System.Windows.Forms.DataGridView();
            this.COL_TABLE_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_Search = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.ds_Main = new System.Data.DataSet();
            this.tbl_TableName = new System.Data.DataTable();
            this.TABLE_NAME = new System.Data.DataColumn();
            this.tbl_FieldList = new System.Data.DataTable();
            this.dataColumn1 = new System.Data.DataColumn();
            this.dataColumn2 = new System.Data.DataColumn();
            this.panel_Center = new System.Windows.Forms.Panel();
            this.panel_Edit = new System.Windows.Forms.Panel();
            this.tab_Edit = new System.Windows.Forms.TabControl();
            this.tabPage_Entity = new System.Windows.Forms.TabPage();
            this.rtb_Pojo = new System.Windows.Forms.RichTextBox();
            this.tabPage_Support = new System.Windows.Forms.TabPage();
            this.rtb_Support = new System.Windows.Forms.RichTextBox();
            this.panel_Right = new System.Windows.Forms.Panel();
            this.dgv_TableField = new System.Windows.Forms.DataGridView();
            this.COL_COLUMN_NAME = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.COL_DATA_TYPE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel_Top_TableSpec = new System.Windows.Forms.Panel();
            this.lbl_FieldList = new System.Windows.Forms.Label();
            this.tabPage_Mapper = new System.Windows.Forms.TabPage();
            this.rtb_Mapper = new System.Windows.Forms.RichTextBox();
            this.panel_Top.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Online)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Off)).BeginInit();
            this.statusStrip_Main.SuspendLayout();
            this.panel_Left.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Table)).BeginInit();
            this.panel_Search.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Main)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_TableName)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_FieldList)).BeginInit();
            this.panel_Center.SuspendLayout();
            this.panel_Edit.SuspendLayout();
            this.tab_Edit.SuspendLayout();
            this.tabPage_Entity.SuspendLayout();
            this.tabPage_Support.SuspendLayout();
            this.panel_Right.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TableField)).BeginInit();
            this.panel_Top_TableSpec.SuspendLayout();
            this.tabPage_Mapper.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Top
            // 
            this.panel_Top.Controls.Add(this.btn_MakeModel);
            this.panel_Top.Controls.Add(this.btn_Close);
            this.panel_Top.Controls.Add(this.pic_Online);
            this.panel_Top.Controls.Add(this.pic_Off);
            this.panel_Top.Controls.Add(this.btn_Connect);
            this.panel_Top.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Top.Location = new System.Drawing.Point(0, 0);
            this.panel_Top.Name = "panel_Top";
            this.panel_Top.Size = new System.Drawing.Size(1149, 50);
            this.panel_Top.TabIndex = 0;
            // 
            // btn_MakeModel
            // 
            this.btn_MakeModel.BackColor = System.Drawing.Color.White;
            this.btn_MakeModel.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_MakeModel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MakeModel.ForeColor = System.Drawing.Color.Black;
            this.btn_MakeModel.Location = new System.Drawing.Point(269, 8);
            this.btn_MakeModel.Name = "btn_MakeModel";
            this.btn_MakeModel.Size = new System.Drawing.Size(111, 32);
            this.btn_MakeModel.TabIndex = 5;
            this.btn_MakeModel.Text = "모델 생성";
            this.btn_MakeModel.UseVisualStyleBackColor = false;
            this.btn_MakeModel.Click += new System.EventHandler(this.btn_MakePojo_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.BackColor = System.Drawing.Color.White;
            this.btn_Close.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Close.ForeColor = System.Drawing.Color.Black;
            this.btn_Close.Location = new System.Drawing.Point(163, 8);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(85, 32);
            this.btn_Close.TabIndex = 4;
            this.btn_Close.Text = "DB해제";
            this.btn_Close.UseVisualStyleBackColor = false;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // pic_Online
            // 
            this.pic_Online.Image = global::SysoneModel.Properties.Resources.ic_swap_vertical_circle_white_24dp;
            this.pic_Online.Location = new System.Drawing.Point(12, 8);
            this.pic_Online.Name = "pic_Online";
            this.pic_Online.Size = new System.Drawing.Size(36, 36);
            this.pic_Online.TabIndex = 3;
            this.pic_Online.TabStop = false;
            // 
            // pic_Off
            // 
            this.pic_Off.Image = global::SysoneModel.Properties.Resources.ic_settings_input_component_white_24dp;
            this.pic_Off.Location = new System.Drawing.Point(12, 8);
            this.pic_Off.Name = "pic_Off";
            this.pic_Off.Size = new System.Drawing.Size(36, 36);
            this.pic_Off.TabIndex = 2;
            this.pic_Off.TabStop = false;
            // 
            // btn_Connect
            // 
            this.btn_Connect.BackColor = System.Drawing.Color.White;
            this.btn_Connect.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.btn_Connect.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Connect.ForeColor = System.Drawing.Color.Black;
            this.btn_Connect.Location = new System.Drawing.Point(72, 8);
            this.btn_Connect.Name = "btn_Connect";
            this.btn_Connect.Size = new System.Drawing.Size(85, 32);
            this.btn_Connect.TabIndex = 1;
            this.btn_Connect.Text = "DB연결";
            this.btn_Connect.UseVisualStyleBackColor = false;
            this.btn_Connect.Click += new System.EventHandler(this.btn_Connect_Click);
            // 
            // statusStrip_Main
            // 
            this.statusStrip_Main.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.status_Connect,
            this.toolStripStatusLabel2});
            this.statusStrip_Main.Location = new System.Drawing.Point(0, 479);
            this.statusStrip_Main.Name = "statusStrip_Main";
            this.statusStrip_Main.Size = new System.Drawing.Size(1149, 22);
            this.statusStrip_Main.TabIndex = 2;
            this.statusStrip_Main.Text = "statusStrip1";
            // 
            // status_Connect
            // 
            this.status_Connect.AutoSize = false;
            this.status_Connect.Name = "status_Connect";
            this.status_Connect.Size = new System.Drawing.Size(200, 17);
            this.status_Connect.Text = "연결대기";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(121, 17);
            this.toolStripStatusLabel2.Text = "toolStripStatusLabel2";
            // 
            // panel_Left
            // 
            this.panel_Left.Controls.Add(this.dgv_Table);
            this.panel_Left.Controls.Add(this.panel_Search);
            this.panel_Left.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel_Left.Location = new System.Drawing.Point(0, 50);
            this.panel_Left.Name = "panel_Left";
            this.panel_Left.Size = new System.Drawing.Size(220, 429);
            this.panel_Left.TabIndex = 3;
            // 
            // dgv_Table
            // 
            this.dgv_Table.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Table.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COL_TABLE_NAME});
            this.dgv_Table.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_Table.Location = new System.Drawing.Point(0, 32);
            this.dgv_Table.Name = "dgv_Table";
            this.dgv_Table.RowTemplate.Height = 23;
            this.dgv_Table.Size = new System.Drawing.Size(220, 397);
            this.dgv_Table.TabIndex = 1;
            this.dgv_Table.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Table_CellClick);
            // 
            // COL_TABLE_NAME
            // 
            this.COL_TABLE_NAME.HeaderText = "테이블명";
            this.COL_TABLE_NAME.Name = "COL_TABLE_NAME";
            this.COL_TABLE_NAME.Width = 150;
            // 
            // panel_Search
            // 
            this.panel_Search.Controls.Add(this.textBox1);
            this.panel_Search.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Search.Location = new System.Drawing.Point(0, 0);
            this.panel_Search.Name = "panel_Search";
            this.panel_Search.Size = new System.Drawing.Size(220, 32);
            this.panel_Search.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(3, 6);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(214, 21);
            this.textBox1.TabIndex = 0;
            // 
            // ds_Main
            // 
            this.ds_Main.DataSetName = "NewDataSet";
            this.ds_Main.Tables.AddRange(new System.Data.DataTable[] {
            this.tbl_TableName,
            this.tbl_FieldList});
            // 
            // tbl_TableName
            // 
            this.tbl_TableName.Columns.AddRange(new System.Data.DataColumn[] {
            this.TABLE_NAME});
            this.tbl_TableName.TableName = "tbl_TableName";
            // 
            // TABLE_NAME
            // 
            this.TABLE_NAME.ColumnName = "TABLE_NAME";
            // 
            // tbl_FieldList
            // 
            this.tbl_FieldList.Columns.AddRange(new System.Data.DataColumn[] {
            this.dataColumn1,
            this.dataColumn2});
            this.tbl_FieldList.TableName = "tbl_FieldList";
            // 
            // dataColumn1
            // 
            this.dataColumn1.ColumnName = "COLUMN_NAME";
            // 
            // dataColumn2
            // 
            this.dataColumn2.ColumnName = "DATA_TYPE";
            // 
            // panel_Center
            // 
            this.panel_Center.Controls.Add(this.panel_Edit);
            this.panel_Center.Controls.Add(this.panel_Right);
            this.panel_Center.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Center.Location = new System.Drawing.Point(220, 50);
            this.panel_Center.Name = "panel_Center";
            this.panel_Center.Size = new System.Drawing.Size(929, 429);
            this.panel_Center.TabIndex = 4;
            // 
            // panel_Edit
            // 
            this.panel_Edit.Controls.Add(this.tab_Edit);
            this.panel_Edit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel_Edit.Location = new System.Drawing.Point(0, 0);
            this.panel_Edit.Name = "panel_Edit";
            this.panel_Edit.Size = new System.Drawing.Size(638, 429);
            this.panel_Edit.TabIndex = 1;
            // 
            // tab_Edit
            // 
            this.tab_Edit.Controls.Add(this.tabPage_Entity);
            this.tab_Edit.Controls.Add(this.tabPage_Support);
            this.tab_Edit.Controls.Add(this.tabPage_Mapper);
            this.tab_Edit.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tab_Edit.Location = new System.Drawing.Point(0, 0);
            this.tab_Edit.Name = "tab_Edit";
            this.tab_Edit.SelectedIndex = 0;
            this.tab_Edit.Size = new System.Drawing.Size(638, 429);
            this.tab_Edit.TabIndex = 0;
            // 
            // tabPage_Entity
            // 
            this.tabPage_Entity.Controls.Add(this.rtb_Pojo);
            this.tabPage_Entity.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Entity.Name = "tabPage_Entity";
            this.tabPage_Entity.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Entity.Size = new System.Drawing.Size(630, 403);
            this.tabPage_Entity.TabIndex = 0;
            this.tabPage_Entity.Text = "Entity";
            this.tabPage_Entity.UseVisualStyleBackColor = true;
            // 
            // rtb_Pojo
            // 
            this.rtb_Pojo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_Pojo.Location = new System.Drawing.Point(3, 3);
            this.rtb_Pojo.Name = "rtb_Pojo";
            this.rtb_Pojo.Size = new System.Drawing.Size(624, 397);
            this.rtb_Pojo.TabIndex = 0;
            this.rtb_Pojo.Text = "";
            // 
            // tabPage_Support
            // 
            this.tabPage_Support.Controls.Add(this.rtb_Support);
            this.tabPage_Support.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Support.Name = "tabPage_Support";
            this.tabPage_Support.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage_Support.Size = new System.Drawing.Size(630, 403);
            this.tabPage_Support.TabIndex = 1;
            this.tabPage_Support.Text = "Table Support";
            this.tabPage_Support.UseVisualStyleBackColor = true;
            // 
            // rtb_Support
            // 
            this.rtb_Support.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_Support.Location = new System.Drawing.Point(3, 3);
            this.rtb_Support.Name = "rtb_Support";
            this.rtb_Support.Size = new System.Drawing.Size(624, 397);
            this.rtb_Support.TabIndex = 0;
            this.rtb_Support.Text = "";
            // 
            // panel_Right
            // 
            this.panel_Right.Controls.Add(this.dgv_TableField);
            this.panel_Right.Controls.Add(this.panel_Top_TableSpec);
            this.panel_Right.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel_Right.Location = new System.Drawing.Point(638, 0);
            this.panel_Right.Name = "panel_Right";
            this.panel_Right.Size = new System.Drawing.Size(291, 429);
            this.panel_Right.TabIndex = 0;
            // 
            // dgv_TableField
            // 
            this.dgv_TableField.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_TableField.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.COL_COLUMN_NAME,
            this.COL_DATA_TYPE});
            this.dgv_TableField.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgv_TableField.Location = new System.Drawing.Point(0, 32);
            this.dgv_TableField.Name = "dgv_TableField";
            this.dgv_TableField.RowTemplate.Height = 23;
            this.dgv_TableField.Size = new System.Drawing.Size(291, 397);
            this.dgv_TableField.TabIndex = 1;
            // 
            // COL_COLUMN_NAME
            // 
            this.COL_COLUMN_NAME.HeaderText = "컬럼명";
            this.COL_COLUMN_NAME.Name = "COL_COLUMN_NAME";
            // 
            // COL_DATA_TYPE
            // 
            this.COL_DATA_TYPE.HeaderText = "데이터타입";
            this.COL_DATA_TYPE.Name = "COL_DATA_TYPE";
            // 
            // panel_Top_TableSpec
            // 
            this.panel_Top_TableSpec.Controls.Add(this.lbl_FieldList);
            this.panel_Top_TableSpec.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel_Top_TableSpec.Location = new System.Drawing.Point(0, 0);
            this.panel_Top_TableSpec.Name = "panel_Top_TableSpec";
            this.panel_Top_TableSpec.Size = new System.Drawing.Size(291, 32);
            this.panel_Top_TableSpec.TabIndex = 0;
            // 
            // lbl_FieldList
            // 
            this.lbl_FieldList.AutoSize = true;
            this.lbl_FieldList.Location = new System.Drawing.Point(6, 9);
            this.lbl_FieldList.Name = "lbl_FieldList";
            this.lbl_FieldList.Size = new System.Drawing.Size(93, 12);
            this.lbl_FieldList.TabIndex = 0;
            this.lbl_FieldList.Text = "테이블 필드정의";
            // 
            // tabPage_Mapper
            // 
            this.tabPage_Mapper.Controls.Add(this.rtb_Mapper);
            this.tabPage_Mapper.Location = new System.Drawing.Point(4, 22);
            this.tabPage_Mapper.Name = "tabPage_Mapper";
            this.tabPage_Mapper.Size = new System.Drawing.Size(630, 403);
            this.tabPage_Mapper.TabIndex = 2;
            this.tabPage_Mapper.Text = "Mapper";
            this.tabPage_Mapper.UseVisualStyleBackColor = true;
            // 
            // rtb_Mapper
            // 
            this.rtb_Mapper.Dock = System.Windows.Forms.DockStyle.Fill;
            this.rtb_Mapper.Location = new System.Drawing.Point(0, 0);
            this.rtb_Mapper.Name = "rtb_Mapper";
            this.rtb_Mapper.Size = new System.Drawing.Size(630, 403);
            this.rtb_Mapper.TabIndex = 0;
            this.rtb_Mapper.Text = "";
            // 
            // Form_Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1149, 501);
            this.Controls.Add(this.panel_Center);
            this.Controls.Add(this.panel_Left);
            this.Controls.Add(this.statusStrip_Main);
            this.Controls.Add(this.panel_Top);
            this.Name = "Form_Main";
            this.Text = "SysoneModel";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form_Main_FormClosing);
            this.Load += new System.EventHandler(this.Form_Main_Load);
            this.panel_Top.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_Online)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Off)).EndInit();
            this.statusStrip_Main.ResumeLayout(false);
            this.statusStrip_Main.PerformLayout();
            this.panel_Left.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Table)).EndInit();
            this.panel_Search.ResumeLayout(false);
            this.panel_Search.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ds_Main)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_TableName)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tbl_FieldList)).EndInit();
            this.panel_Center.ResumeLayout(false);
            this.panel_Edit.ResumeLayout(false);
            this.tab_Edit.ResumeLayout(false);
            this.tabPage_Entity.ResumeLayout(false);
            this.tabPage_Support.ResumeLayout(false);
            this.panel_Right.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_TableField)).EndInit();
            this.panel_Top_TableSpec.ResumeLayout(false);
            this.panel_Top_TableSpec.PerformLayout();
            this.tabPage_Mapper.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel_Top;
        private System.Windows.Forms.StatusStrip statusStrip_Main;
        private System.Windows.Forms.Panel panel_Left;
        private System.Windows.Forms.Button btn_Connect;
        private System.Windows.Forms.PictureBox pic_Off;
        private System.Windows.Forms.ToolStripStatusLabel status_Connect;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.PictureBox pic_Online;
        private System.Windows.Forms.DataGridView dgv_Table;
        private System.Windows.Forms.Panel panel_Search;
        private System.Windows.Forms.TextBox textBox1;
        private System.Data.DataSet ds_Main;
        private System.Windows.Forms.DataGridViewTextBoxColumn COL_TABLE_NAME;
        private System.Data.DataTable tbl_TableName;
        private System.Data.DataColumn TABLE_NAME;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.Button btn_MakeModel;
        private System.Windows.Forms.Panel panel_Center;
        private System.Windows.Forms.Panel panel_Edit;
        private System.Windows.Forms.TabControl tab_Edit;
        private System.Windows.Forms.TabPage tabPage_Entity;
        private System.Windows.Forms.TabPage tabPage_Support;
        private System.Windows.Forms.Panel panel_Right;
        private System.Windows.Forms.RichTextBox rtb_Pojo;
        private System.Windows.Forms.RichTextBox rtb_Support;
        private System.Windows.Forms.Panel panel_Top_TableSpec;
        private System.Windows.Forms.DataGridView dgv_TableField;
        private System.Windows.Forms.Label lbl_FieldList;
        private System.Data.DataTable tbl_FieldList;
        private System.Data.DataColumn dataColumn1;
        private System.Data.DataColumn dataColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn COL_COLUMN_NAME;
        private System.Windows.Forms.DataGridViewTextBoxColumn COL_DATA_TYPE;
        private System.Windows.Forms.TabPage tabPage_Mapper;
        private System.Windows.Forms.RichTextBox rtb_Mapper;
    }
}

